library(tidyverse)
library(magrittr)
library(xml2)

input_file = "./current_input_file"
flextext = read_xml(input_file)
output_file = gsub("\\.flextext",".eaf",input_file)

##You must have the following packages for the script to work
packages = c("xml2","tidyverse","magrittr")

##Install packages if not present. When present, load
package.check <- lapply(
  packages,
  FUN = function(x) {
    if (!require(x, character.only = TRUE)) {
      install.packages(x, dependencies = TRUE)
      library(x, character.only = TRUE)
    }
  }
)

###Metadata

#Extract metadata
metadata_nodes = xml_find_all(flextext,".//interlinear-text/item")

get_metadata = function(xml_node){
  text = xml_text(xml_node)
  type = xml_attr(xml_node,"type")
  lang = xml_attr(xml_node,"lang")
  vector = c(text,type,lang)
  return(vector)
}

#Make table of metadata nodes
metadata_vector <- vector("character",length(metadata_nodes))
metadata_table <- tibble(text=metadata_vector,type=metadata_vector,lang=metadata_vector)
for (i in 1:length(metadata_nodes)) (
  metadata_table[i,] = get_metadata(metadata_nodes[[i]])
)
metadata_table <- metadata_table %>%
  unite("type",c("type","lang"),sep="_")

###Paragraphs (main text)

phrase_nodes = xml_find_all(flextext,".//interlinear-text//paragraphs/paragraph/phrases/phrase")
phrase_table_list = as.list(vector("character",length(phrase_nodes)))

#Define function to concatenate punctuation without extra space
paste_for_flexwords = function(character_vector){
  newvector = paste(character_vector,sep=" ",collapse=" ")
  opening_punct=c("“","\\(","\\{","\\[")
  opening_punct_spaces=paste(opening_punct," ",sep="")
  closing_punct=c("”","\\)","\\}","\\]","\\.",",",":",";","\\?","!")
  closing_punct_spaces=paste(" ",closing_punct,sep="")
  all_punct=c(opening_punct,closing_punct)
  all_punct_spaces=c(opening_punct_spaces,closing_punct_spaces)
  for (i in 1:length(all_punct)) (
    newvector = gsub(all_punct_spaces[i],all_punct[i],newvector)
  )
  return(newvector)
}

#Define function to parse a word
get_word_parse = function(word_node){
  word_text = xml_text(xml_find_all(word_node,"./item"))
  word_guid = xml_attr(word_node,"guid")
  morpheme_nodes = xml_find_all(word_node,"./morphemes/morph")
  morpheme_vector <- vector("character",length(morpheme_nodes))
  morpheme_table = tibble(txt=morpheme_vector,cf=morpheme_vector,gls_en=morpheme_vector,gls_es=morpheme_vector)
  for (i in 1:length(morpheme_nodes)) (
    morpheme_table[i,] = c(
      xml_text(xml_find_all(morpheme_nodes[[i]],"./item[@type='txt']")),
      xml_text(xml_find_all(morpheme_nodes[[i]],"./item[@type='cf']")),
      xml_text(xml_find_all(morpheme_nodes[[i]],"./item[@type='gls' and @lang='en']")),
      xml_text(xml_find_all(morpheme_nodes[[i]],"./item[@type='gls' and @lang='es']"))
    )
  )
  morpheme_table <- morpheme_table %>%
    mutate(word=word_text,word_guid=word_guid)
  return(morpheme_table)
}

#Define function to pull everything for a phrase
get_phrase = function(phrase_node){
#Metadata
phrase_attrs = tibble(begin_time = xml_attr(phrase_node,"begin-time-offset"),
                 end_time = xml_attr(phrase_node,"end-time-offset"),
                 speaker = xml_attr(phrase_node,"speaker"),
                 guid = xml_attr(phrase_node,"guid"),
                 media_file = xml_attr(phrase_node,"media-file")
                 )

#Object language content of *entire phrase*
phrase_words = xml_find_all(phrase_node,"./words/word/item")
phrase_lang = xml_attr(xml_find_first(phrase_node,"./words/word/item[@type='txt']"),"lang")
phrase_string = paste_for_flexwords(xml_text(phrase_words))
phrase_vector = tibble(text=phrase_string,type="phrase",lang=phrase_lang)

#Metalanguage translations and notes on *entire phrase*
phrase_gls_nodes = xml_find_all(phrase_node,"./item[@type='gls']")
phrase_gls_vector <- vector("character",length(phrase_gls_nodes))
phrase_gls_table = tibble(text=phrase_gls_vector,type=phrase_gls_vector,lang=phrase_gls_vector)
for (i in 1:length(phrase_gls_nodes)) (
  phrase_gls_table[i,] = get_metadata(phrase_gls_nodes[[i]])
)
phrase_gls_table = rbind(phrase_vector,phrase_gls_table) %>%
 pivot_wider(names_from=c("type","lang"),values_from="text")

#Word parses
word_nodes = xml_find_all(phrase_node,"./words/word[item/@type='txt']")
word_parse_list = as.list(vector("character",length(word_nodes)))
for (i in 1:length(word_nodes)) (
  word_parse_list[[i]] = get_word_parse(word_nodes[[i]])
)
word_parse_table <- bind_rows(word_parse_list)
final_list = as.list(c(phrase_attrs=phrase_attrs,
                       phrase_table=phrase_gls_table,
                       word_table=word_parse_table))
return(final_list)
}

for (i in 1:length(phrase_table_list)) (
  phrase_table_list[[i]] = get_phrase(phrase_nodes[[i]])
)

#Extract media info
media_node = xml_find_first(flextext,".//interlinear-text//media-files")
media_guid = xml_attr(xml_find_first(media_node,"./media"),"guid")
media_location = xml_attr(xml_find_first(media_node,"./media"),"location")
media_offset = xml_attr(media_node,"offset")

#Create timeslots for EAF
begin_timevalues = tibble(timevalue=vector("numeric",length(phrase_nodes)),guid=vector("character",length(phrase_nodes)))
end_timevalues = tibble(timevalue=vector("numeric",length(phrase_nodes)),guid=vector("character",length(phrase_nodes)))
for (i in 1:length(phrase_nodes))(
  begin_timevalues[i,] = c(phrase_table_list[[i]]$phrase_attrs.begin_time,phrase_table_list[[i]]$phrase_attrs.guid)
)
for (i in 1:length(phrase_nodes))(
  end_timevalues[i,] = c(phrase_table_list[[i]]$phrase_attrs.end_time,phrase_table_list[[i]]$phrase_attrs.guid)
)
begin_timevalues <- column_to_rownames(begin_timevalues,var="guid")
#0 timeslot for text-level metadata
begin_timevalues <- rbind(no_guid="0",begin_timevalues)
begin_timevalues$timeslot <- as.character(paste("ts",seq(from=1,to=(2*nrow(begin_timevalues)-1),by=2),sep=""))
end_timevalues <- column_to_rownames(end_timevalues,var="guid") 
#extra final timeslot for text-level metadata
end_timevalues <- rbind(end_timevalues,no_guid=max(end_timevalues[,1]))
end_timevalues$timeslot <- as.character(paste("ts",seq(from=2,to=(2*nrow(begin_timevalues)),by=2),sep=""))
#Transform begin and end times of phrase tiers to have timeslot ID's rather than time values
begin_timeslot <- function(guid)(
  begin_timevalues[guid,2]
)
end_timeslot <- function(guid)(
  end_timevalues[guid,2]
)
for (i in 1:length(phrase_table_list)) (
  phrase_table_list[[i]]$phrase_attrs.begin_time = begin_timeslot(phrase_table_list[[i]]$phrase_attrs.guid)
)
for (i in 1:length(phrase_table_list)) (
  phrase_table_list[[i]]$phrase_attrs.end_time = end_timeslot(phrase_table_list[[i]]$phrase_attrs.guid)
)
timeslot_node_content = rbind(plyr::unrowname(begin_timevalues),plyr::unrowname(end_timevalues)) %>%
  arrange(as.numeric(gsub("ts","",timeslot)))

#Write to EAF

#Header
eaf = xml_new_root("ANNOTATION_DOCUMENT")
root = xml_root(eaf)
date=as.character(lubridate::now("GMT"))
date=gsub("$","-00:00",date)
date=gsub(" ","T",date)
xml_attrs(root) <- c("AUTHOR"="unspecified","DATE"=date,"FORMAT"="3.0","VERSION"="3.0","xmlns:xsi"="http://www.w3.org/2001/XMLSchema-instance","xsi:noNamespaceSchemaLocation"="http://www.mpi.nl/tools/elan/EAFv3.0.xsd")
xml_add_child(root,"HEADER")
header = xml_find_first(root,"./HEADER")
xml_attrs(header) <- c("MEDIA_FILE"="","TIME_UNITS"="milliseconds")
xml_add_child(header,"MEDIA_DESCRIPTOR")
media_descriptor = xml_find_first(header,"./MEDIA_DESCRIPTOR")
xml_attrs(media_descriptor) <- c("MEDIA_URL"=media_location,
"MIME_TYPE"="audio/x-wav",
"RELATIVE_MEDIA_URL"=paste("../../../",gsub("file:///Users/","",media_location),sep="")
)
if(!is.na(media_offset)) {
  xml_attr(media_descriptor,"TIME_ORIGIN") <- media_offset
}
xml_add_child(header,"PROPERTY")
xml_add_child(header,"PROPERTY")
properties = xml_find_all(header,"PROPERTY")
xml_attrs(properties[[1]]) <- c("NAME"="URN")
xml_text(properties[[1]]) <- "urn:nl-mpi-tools-elan-eaf:6598a8be-9422-41bf-86b3-e95f79bb4aa7"
xml_attrs(properties[[2]]) <- c("NAME"="lastUsedAnnotationId")
xml_text(properties[[2]]) <- "0"
xml_add_child(root,"TIME_ORDER")
time_order = xml_find_first(root,"./TIME_ORDER")
add_timeslot <- function(timeslot_number){
  xml_add_child(time_order,"TIME_SLOT")
  time_slots = xml_find_all(time_order,"./TIME_SLOT")
  xml_attrs(time_slots[[timeslot_number]]) <- c("TIME_SLOT_ID"=as.character(timeslot_node_content[timeslot_number,2]),
                                                "TIME_VALUE"=as.character(timeslot_node_content[timeslot_number,1]))
}
for (i in 1:nrow(timeslot_node_content)) (
  add_timeslot(i)
)

#Create tiers
#Make list of tiers
#Each tier is a list with names with its future name, containing linguistic type and parent if applicable
tier_list <- list(title_iqu=c("metadata"),
                  title_en=c("phrase_gls","title_iqu"),
                  title_es=c("phrase_gls","title_iqu"),
                  phrase_iqu=c("phrase_iqu"),
                  phrase_gls_en=c("phrase_gls","phrase_iqu"),
                  phrase_gls_es=c("phrase_gls","phrase_iqu"),
                  phrase_gls_spq=c("phrase_gls","phrase_iqu"),
                  phrase_gls_ga=c("phrase_gls","phrase_iqu"),
                  word=c("word","phrase_iqu"),
                  morph=c("morph","word"),
                  morph_cf=c("morph_gls","morph"),
                  morph_gls_en=c("morph_gls","morph"),
                  morph_gls_es=c("morph_gls","morph")
)

#Function to create a tier
add_tier = function(number){
  xml_add_child(root,"TIER")
  tiers = xml_find_all(root,"./TIER")
  if (length(tier_list[[number]]) == 2) (
    xml_attrs(tiers[[number]]) <- c("LINGUISTIC_TYPE_REF"=tier_list[[number]][1],
                                    "PARENT_REF"=tier_list[[number]][2],
                                    "TIER_ID"=names(tier_list)[number])
  ) else 
    xml_attrs(tiers[[number]]) <- c("LINGUISTIC_TYPE_REF"=tier_list[[number]][1],
                                    "TIER_ID"=names(tier_list)[number])
}

#Actually add tiers
for (i in 1:length(tier_list)) (add_tier(i))

#Footer: Linguistic types
xml_add_child(root,"LINGUISTIC_TYPE")
xml_add_child(root,"LINGUISTIC_TYPE")
xml_add_child(root,"LINGUISTIC_TYPE")
xml_add_child(root,"LINGUISTIC_TYPE")
xml_add_child(root,"LINGUISTIC_TYPE")
xml_add_child(root,"LINGUISTIC_TYPE")
linguistic_types = xml_find_all(root,"./LINGUISTIC_TYPE")
xml_attrs(linguistic_types[[1]]) <- c("GRAPHIC_REFERENCES"="false",
                                      "LINGUISTIC_TYPE_ID"="phrase_iqu",
                                      "TIME_ALIGNABLE"="true")
xml_attrs(linguistic_types[[2]]) <- c("CONSTRAINTS"="Symbolic_Association",
                                      "GRAPHIC_REFERENCES"="false",
                                      "LINGUISTIC_TYPE_ID"="phrase_gls",
                                      "TIME_ALIGNABLE"="false")
xml_attrs(linguistic_types[[3]]) <- c("CONSTRAINTS"="Symbolic_Subdivision",
                                      "GRAPHIC_REFERENCES"="false",
                                      "LINGUISTIC_TYPE_ID"="word",
                                      "TIME_ALIGNABLE"="false")
xml_attrs(linguistic_types[[4]]) <- c("CONSTRAINTS"="Symbolic_Subdivision",
                                      "GRAPHIC_REFERENCES"="false",
                                      "LINGUISTIC_TYPE_ID"="morph",
                                      "TIME_ALIGNABLE"="false")
xml_attrs(linguistic_types[[5]]) <- c("CONSTRAINTS"="Symbolic_Association",
                                      "GRAPHIC_REFERENCES"="false",
                                      "LINGUISTIC_TYPE_ID"="morph_gls",
                                      "TIME_ALIGNABLE"="false")
xml_attrs(linguistic_types[[6]]) <- c("GRAPHIC_REFERENCES"="false",
                                      "LINGUISTIC_TYPE_ID"="metadata",
                                      "TIME_ALIGNABLE"="true")
xml_add_child(root,"CONSTRAINT")
xml_add_child(root,"CONSTRAINT")
xml_add_child(root,"CONSTRAINT")
xml_add_child(root,"CONSTRAINT")
constraints = xml_find_all(root,"./CONSTRAINT")
xml_attrs(constraints[[1]]) <- c("DESCRIPTION"="Time subdivision of parent annotation's time interval, no time gaps allowed within this interval",
                                 "STEREOTYPE"="Time_Subdivision")
xml_attrs(constraints[[2]]) <- c("DESCRIPTION"="Symbolic subdivision of a parent annotation. Annotations refering to the same parent are ordered",
                                 "STEREOTYPE"="Symbolic_Subdivision")
xml_attrs(constraints[[3]]) <- c("DESCRIPTION"="1-1 association with a parent annotation",
                                 "STEREOTYPE"="Symbolic_Association")
xml_attrs(constraints[[4]]) <- c("DESCRIPTION"="Time alignable annotations within the parent annotation's time interval, gaps are allowed",
                                 "STEREOTYPE"="Included_In")

#Add content to metadata tiers
#Vectors for adding
metadata_tiers_content <- list(title_iqu=c((metadata_table %>% filter(type=="title_iqu"))$text,"ALIGNABLE",timeslot_node_content[1,2],timeslot_node_content[nrow(timeslot_node_content),2]),
                  title_en=c((metadata_table %>% filter(type=="title_en"))$text,"REF"),
                  title_es=c((metadata_table %>% filter(type=="title_es"))$text,"REF")
)

#Function to add metadata annotations
add_metadata_tier = function(number){
  tier = xml_find_first(root,paste("./TIER[@TIER_ID='",names(metadata_tiers_content)[number],"']",sep=""))
  xml_add_child(tier,"ANNOTATION")
  annotation = xml_find_first(tier,"./ANNOTATION")
  if ((metadata_tiers_content[[number]][2]) == "ALIGNABLE") {
   xml_add_child(annotation,"ALIGNABLE_ANNOTATION") 
   alignable_annotation = xml_find_first(annotation,"./ALIGNABLE_ANNOTATION")
   xml_attrs(alignable_annotation) <- c("ANNOTATION_ID"=paste("a",number,sep=""),
                                        "TIME_SLOT_REF1"=metadata_tiers_content[[number]][3],
                                        "TIME_SLOT_REF2"=metadata_tiers_content[[number]][4])
   xml_add_child(alignable_annotation,"ANNOTATION_VALUE")
   annotation_value = xml_find_first(alignable_annotation,"ANNOTATION_VALUE")
  }
  else {
    xml_add_child(annotation,"REF_ANNOTATION") 
    ref_annotation = xml_find_first(annotation,"./REF_ANNOTATION")
    xml_attrs(ref_annotation) <- c("ANNOTATION_ID"=paste("a",number,sep=""),
                                         "ANNOTATION_REF"="a1")
    xml_add_child(ref_annotation,"ANNOTATION_VALUE")
    annotation_value = xml_find_first(ref_annotation,"ANNOTATION_VALUE")
  }
  xml_text(annotation_value) <- metadata_tiers_content[[number]][1]
}

#Actually add
for (i in 1:length(metadata_tiers_content)) (add_metadata_tier(i))

#Add content to phrase tiers

#Get content
phrase_table = matrix(0,ncol=8,nrow=length(phrase_table_list))
phrase_table = data.frame(phrase_table)
names(phrase_table) = names(phrase_table_list[[1]][c(1:2,4,6:10)])
for (i in 1:length(phrase_table_list)) (
  phrase_table[i,] = phrase_table_list[[i]][c(1:2,4,6:10)]
)
names(phrase_table) = c("begin_time","end_time","guid",names(tier_list)[4:8])

#Create annotation IDs
phrase_table <- phrase_table %>%
  mutate(phrase_iqu_aid=seq(from=4,to=3+nrow(phrase_table),by=1)) %>%
  mutate(phrase_gls_en_aid=seq(from=1+max(phrase_iqu_aid),to=max(phrase_iqu_aid)+nrow(phrase_table),by=1)) %>%
  mutate(phrase_gls_es_aid=seq(from=1+max(phrase_gls_en_aid),to=max(phrase_gls_en_aid)+nrow(phrase_table),by=1)) %>%
  mutate(phrase_gls_spq_aid=seq(from=1+max(phrase_gls_es_aid),to=max(phrase_gls_es_aid)+nrow(phrase_table),by=1)) %>%
  mutate(phrase_gls_ga_aid=seq(from=1+max(phrase_gls_spq_aid),to=max(phrase_gls_spq_aid)+nrow(phrase_table),by=1))

#Function to add phrase annotations
add_phrase_tier = function(number){
  tier = xml_find_first(root,paste("./TIER[@TIER_ID='",names(phrase_table)[number],"']",sep=""))
  for (i in 1:nrow(phrase_table)) {
  xml_add_child(tier,"ANNOTATION")
  annotation = xml_find_all(tier,"./ANNOTATION")
  if (names(phrase_table)[number] == "phrase_iqu") {
    xml_add_child(annotation[[i]],"ALIGNABLE_ANNOTATION") 
    alignable_annotation = xml_find_first(annotation[[i]],"./ALIGNABLE_ANNOTATION")
    xml_attrs(alignable_annotation) <- c("ANNOTATION_ID"=paste("a",phrase_table[i,number+5],sep=""),
                                         "TIME_SLOT_REF1"=phrase_table[i,1],
                                         "TIME_SLOT_REF2"=phrase_table[i,2],
                                         "GUID"=phrase_table[i,3])
    xml_add_child(alignable_annotation,"ANNOTATION_VALUE")
    annotation_value = xml_find_first(alignable_annotation,"ANNOTATION_VALUE")
    xml_text(annotation_value) <- phrase_table[i,4]
  }
  else {
    xml_add_child(annotation[[i]],"REF_ANNOTATION") 
    ref_annotation = xml_find_first(annotation[[i]],"./REF_ANNOTATION")
    xml_attrs(ref_annotation) <- c("ANNOTATION_ID"=paste("a",phrase_table[i,number+5],sep=""),
                                   "ANNOTATION_REF"=paste("a",phrase_table[i,9],sep=""))
    xml_add_child(ref_annotation,"ANNOTATION_VALUE")
    annotation_value = xml_find_first(ref_annotation,"ANNOTATION_VALUE")
    xml_text(annotation_value) <- phrase_table[i,number]
  }
  }
}

#Acutally add
for (i in 4:8) (add_phrase_tier(i))

#Add word annotations
#Get the list of words for each phrase in phrase_table_list$word_table.word, together with guid of phrase
wordtier_content <- list(wordlist=vector("list",length(phrase_table_list)),
                         word_guidlist=vector("list",length(phrase_table_list)),
                         phrase_guid=vector("character",length(phrase_table_list))
)
for (i in 1:length(phrase_table_list)) {
  wordtier_content[["wordlist"]][[i]] = vector("list",length(unique(phrase_table_list[[i]]$word_table.word)))
  wordtier_content[["wordlist"]][[i]] = unique(phrase_table_list[[i]]$word_table.word)
  wordtier_content[["word_guidlist"]][[i]] = vector("list",length(unique(phrase_table_list[[i]]$word_table.word_guid)))
  wordtier_content[["word_guidlist"]][[i]] = unique(phrase_table_list[[i]]$word_table.word_guid)
  wordtier_content[["phrase_guid"]][i] = phrase_table_list[[i]]$phrase_attrs.guid 
}
#Create AIDs for each word (sequential across all lists)
current_max_aid <- max(phrase_table$phrase_gls_ga_aid)
for (i in 1:length(wordtier_content[["wordlist"]])) {
new_max_aid <- current_max_aid+length(wordtier_content[["wordlist"]][[i]])
wordtier_content[["wordlist"]][[i]] = tibble(
  wordlist=wordtier_content[["wordlist"]][[i]],
  wordnumber=seq(from=current_max_aid+1,to=new_max_aid),
  word_guid=wordtier_content[["word_guidlist"]][[i]]
)
current_max_aid <- new_max_aid
}
wordtier_content <- list(wordlist=wordtier_content[["wordlist"]],phrase_guid=wordtier_content[["phrase_guid"]])

#Add words
word_annotation_count = 1
word_tier = xml_find_first(root,"./TIER[@TIER_ID='word']")
for (i in 1:length(wordtier_content[["wordlist"]])) {
  parent_path=paste("./TIER[@TIER_ID='phrase_iqu']/ANNOTATION/ALIGNABLE_ANNOTATION[@GUID='",wordtier_content[["phrase_guid"]][i],"']",sep="")
  annotation_id=xml_attr(xml_find_first(root,parent_path),"ANNOTATION_ID")
  for (j in 1:nrow(wordtier_content[["wordlist"]][[i]])) {
  ##Make an annotation for the first word in the list
    xml_add_child(word_tier,"ANNOTATION")
    word_annotation = (xml_find_all(word_tier,"./ANNOTATION"))[[word_annotation_count]]
    ##Give it the attrs of the word AID and phrase parent AID from the list
    ##If not first word in list, also include preceding word AID
    xml_add_child(word_annotation,"REF_ANNOTATION")
    word_annotation = (xml_find_all(word_tier,"./ANNOTATION/REF_ANNOTATION"))[[word_annotation_count]]
    if (j == 1) {
      xml_attrs(word_annotation) = c("ANNOTATION_ID"=paste("a",as.character(wordtier_content[["wordlist"]][[i]][j,2]),sep=""),
                                   "ANNOTATION_REF"=annotation_id,
                                   "GUID"=as.character(wordtier_content[["wordlist"]][[i]][j,3]))
  }
    else {
      xml_attrs(word_annotation) = c("ANNOTATION_ID"=paste("a",as.character(wordtier_content[["wordlist"]][[i]][j,2]),sep=""),
                                   "ANNOTATION_REF"=annotation_id,
                                   "PREVIOUS_ANNOTATION"=paste("a",as.character(wordtier_content[["wordlist"]][[i]][j-1,2]),sep=""),
                                   "GUID"=as.character(wordtier_content[["wordlist"]][[i]][j,3]))
    }
  ##Give the annotation the text from the list
  xml_add_child(word_annotation,"ANNOTATION_VALUE")
  annotation_value = (xml_find_all(word_tier,"./ANNOTATION/REF_ANNOTATION/ANNOTATION_VALUE"))[[word_annotation_count]]
  xml_text(annotation_value) <- as.character(wordtier_content[["wordlist"]][[i]][j,1])
  word_annotation_count = word_annotation_count+1
}
}

#next up: add morphs
#Get the list of morphs for each word in phrase_table_list$word_table.morph, together with guid of word
morphtier_content <- list(vector("list",length(phrase_table_list)))
for (i in 1:length(phrase_table_list)) {
  morphtier_content[[i]] = bind_rows(phrase_table_list[[i]][c(11:14,16)])
}
#Create AIDs for each morph (sequential across all lists)
for (i in 1:length(morphtier_content)) {
  new_max_aid = current_max_aid+nrow(morphtier_content[[i]])
  morphtier_content[[i]]$morphnumber=seq(from=current_max_aid+1,to=new_max_aid)
  current_max_aid = new_max_aid
}

#Add morphs
morph_annotation_count = 1
morph_tier = xml_find_first(root,"./TIER[@TIER_ID='morph']")
for (i in 1:length(morphtier_content)) {
  for (j in 1:nrow(morphtier_content[[i]])) {
    parent_path=paste("./TIER[@TIER_ID='word']/ANNOTATION/REF_ANNOTATION[@GUID='",as.character(morphtier_content[[i]][j,5]),"']",sep="")
    annotation_id=xml_attr(xml_find_first(root,parent_path),"ANNOTATION_ID")
    ##Make an annotation for the first morph in the list
    xml_add_child(morph_tier,"ANNOTATION")
    morph_annotation = (xml_find_all(morph_tier,"./ANNOTATION"))[[morph_annotation_count]]
    ##Give it the attrs of the morph ID and parent word AID
    ##If not first morph in word, also include preceding morph AID
    xml_add_child(morph_annotation,"REF_ANNOTATION")
    morph_annotation = (xml_find_all(morph_tier,"./ANNOTATION/REF_ANNOTATION"))[[morph_annotation_count]]
    if (j == 1) {
      xml_attrs(morph_annotation) = c("ANNOTATION_ID"=paste("a",as.character(morphtier_content[[i]][j,6]),sep=""),
                                     "ANNOTATION_REF"=annotation_id)
    }
    else {
      if (!as.logical(morphtier_content[[i]][j,5] == morphtier_content[[i]][j-1,5])) {
        xml_attrs(morph_annotation) = c("ANNOTATION_ID"=paste("a",as.character(morphtier_content[[i]][j,6]),sep=""),
                                        "ANNOTATION_REF"=annotation_id)
      }
      else 
        xml_attrs(morph_annotation) = c("ANNOTATION_ID"=paste("a",as.character(morphtier_content[[i]][j,6]),sep=""),
                                        "ANNOTATION_REF"=annotation_id,
                                        "PREVIOUS_ANNOTATION"=paste("a",as.character(morphtier_content[[i]][j-1,6]),sep=""))
    }
    ##Give the annotation the text from the list
    xml_add_child(morph_annotation,"ANNOTATION_VALUE")
    annotation_value = (xml_find_all(morph_tier,"./ANNOTATION/REF_ANNOTATION/ANNOTATION_VALUE"))[[morph_annotation_count]]
    xml_text(annotation_value) <- as.character(morphtier_content[[i]][j,1])
    morph_annotation_count = morph_annotation_count+1
  }
}

#Add morph glosses

#Create annotation IDs for morph glosses
for (i in 1:length(morphtier_content)) {
  names(morphtier_content[[i]]) <- c("morph","morph_cf","morph_gls_en","morph_gls_es","word_guid","morphnumber")
  new_max_aid = current_max_aid+nrow(morphtier_content[[i]])
  morphtier_content[[i]]$morph_cf_number=seq(from=current_max_aid+1,to=new_max_aid)
  current_max_aid = new_max_aid
}
for (i in 1:length(morphtier_content)) {
  new_max_aid = current_max_aid+nrow(morphtier_content[[i]])
  morphtier_content[[i]]$morph_gls_en_number=seq(from=current_max_aid+1,to=new_max_aid)
  current_max_aid = new_max_aid
}
for (i in 1:length(morphtier_content)) {
  new_max_aid = current_max_aid+nrow(morphtier_content[[i]])
  morphtier_content[[i]]$morph_gls_es_number=seq(from=current_max_aid+1,to=new_max_aid)
  current_max_aid = new_max_aid
}

morph_gls_annotation_count = 1
add_morph_gls_tier = function(number){
  tier = xml_find_first(root,paste("./TIER[@TIER_ID='",names(morphtier_content[[1]])[number],"']",sep=""))
  for (i in 1:length(morphtier_content)) {
    for (j in 1:nrow(morphtier_content[[i]])) {
    xml_add_child(tier,"ANNOTATION")
    annotation = xml_find_all(tier,"./ANNOTATION")
    xml_add_child(annotation[[morph_gls_annotation_count]],"REF_ANNOTATION") 
    ref_annotation = xml_find_first(annotation[[morph_gls_annotation_count]],"./REF_ANNOTATION")
    xml_attrs(ref_annotation) <- c("ANNOTATION_ID"=paste("a",as.character(morphtier_content[[i]][j,number+5]),sep=""),
                                     "ANNOTATION_REF"=paste("a",as.character(morphtier_content[[i]][j,6]),sep=""))
    xml_add_child(ref_annotation,"ANNOTATION_VALUE")
    annotation_value = xml_find_first(ref_annotation,"ANNOTATION_VALUE")
    xml_text(annotation_value) <- as.character(morphtier_content[[i]][j,number])
    morph_gls_annotation_count = morph_gls_annotation_count+1
    }
  }
}

for (i in 2:4) (add_morph_gls_tier(i))

#Remove GUIDs
guid_path = xml_find_all(root,".//ALIGNABLE_ANNOTATION[@GUID]")
for (i in 1:length(guid_path)) {
  xml_attr(guid_path[[i]],"GUID") <- NULL
}
guid_path_ref = xml_find_all(root,".//REF_ANNOTATION[@GUID]")
for (i in 1:length(guid_path_ref)) {
  xml_attr(guid_path_ref[[i]],"GUID") <- NULL
}

write_xml(eaf,output_file)
