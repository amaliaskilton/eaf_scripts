#EAF_To_SRT
#Amalia Skilton 2020-06-16
#This script works on an EAF.
#It turns user-selected tiers into SRT format subtitles.
#This duplicates the native SRT export capacity of ELAN,
#But is friendlier to scripting.

### REQUIRED USER INPUT ###

#State the path to the file
input_file <- "./current_input_file"

#State the names of the ROOT tiers you want to export.
parent_tiernames <- "current_root_names"

#State the names of the CHILD tiers you want to export.
#No more than 1 child per root tier
#Children must have the stereotype Symbolic Association
child_tiernames <- "current_child_names"

#State the name of the output file if you want anything other than input + ".srt"
output_file <- gsub("\\.eaf",".srt",input_file)

### SCRIPT BODY ###

##You must have the following packages for the script to work
packages = c("xml2","tidyverse","magrittr")

##Install packages if not present. When present, load
package.check <- lapply(
  packages,
  FUN = function(x) {
    if (!require(x, character.only = TRUE)) {
      install.packages(x, dependencies = TRUE)
      library(x, character.only = TRUE)
    }
  }
)

#Load the eaf.
eaf = read_xml(input_file)

#Load the time_slot nodes.
time_slots = xml_find_all(eaf, ".//TIME_SLOT")

#Turn the time_slot nodes into a data frame.
time_slots_df <- as.data.frame(cbind(TIME_SLOT_ID=as.vector(xml_attr(time_slots, "TIME_SLOT_ID")),
                                     TIME_VALUE=as.vector(xml_attr(time_slots, "TIME_VALUE"))),
                               stringsAsFactors = FALSE)
time_slots_df$TIME_VALUE <- as.numeric(time_slots_df$TIME_VALUE)

#Define a function to convert milliseconds (ELAN time format) to HH:MM:SS(.dd) (ASS format)
msec_conversion <- function(ms){
  hrs = ms/(60 * 60 * 1000)
  mins = (hrs %% 1) * 60
  secs = (mins %% 1) * 60
  hrs = trunc(hrs)
  mins = trunc(mins)
  if (mins < 10) (
    mins = paste("0",mins,sep="")
    )
  if (secs < 10) (
    secs = paste("0",secs,sep="")
  )
  paste(hrs, mins, secs, sep = ":")
}

#Use this to convert the TIME_VALUE column into ASS format times.
time_slots_df <- time_slots_df %>%
  mutate(TIME_VALUE_SRT=sapply(TIME_VALUE,msec_conversion))

#Define a function to load annotations on parent tiers.
parent_times_text <- function(tier_name){
  parent_path <- paste(".//TIER[@TIER_ID='",
                            tier_name,
                            "']//ANNOTATION//ALIGNABLE_ANNOTATION",
                            sep="")
  parent_tier = xml_find_all(eaf,parent_path) 
  parent_starttimes = data.frame(xml_attr(parent_tier, "TIME_SLOT_REF1"), stringsAsFactors = FALSE)
  names(parent_starttimes) <- "TIME_SLOT_ID"
  parent_starttimes = left_join(parent_starttimes,time_slots_df,"TIME_SLOT_ID")
  parent_endtimes = data.frame(xml_attr(parent_tier, "TIME_SLOT_REF2"), stringsAsFactors = FALSE)
  names(parent_endtimes) <- "TIME_SLOT_ID"
  parent_endtimes = left_join(parent_endtimes,time_slots_df,"TIME_SLOT_ID")
  parent_text_path <- paste(parent_path,"//ANNOTATION_VALUE",
                                  sep="")
  parent_text = xml_text(xml_find_all(eaf, parent_text_path))
  parent_times_text_df = data.frame(parent_starttimes[,c(2,3)],parent_endtimes[,c(2,3)],parent_text, stringsAsFactors = FALSE) %>%
    rename(StartTime=TIME_VALUE) %>%
    rename(EndTime=TIME_VALUE.1) %>%
    rename(StartTime_SRT=TIME_VALUE_SRT) %>%
    rename(EndTime_SRT=TIME_VALUE_SRT.1)
  return(parent_times_text_df)
  }

#Define a function to load annotations on child tiers.
child_text <- function(child_tier_name){
  child_path <- paste(".//TIER[@TIER_ID='",
                       child_tier_name,
                       "']//ANNOTATION//REF_ANNOTATION",
                       sep="")
  child_tier = xml_find_all(eaf,child_path) 
  child_text = as.vector(xml_text(child_tier))
  return(child_text)
}

#Define a function that returns both.
parent_child_times_text <- function(parent_tier,child_tier) {
  combined_table <- cbind(parent_times_text(parent_tier),
                          child_text=child_text(child_tier))
  combined_table$child_text <- as.character(combined_table$child_text)
  return(combined_table)
  }

#For every parent tier,
#Generate a table of start time, end time, parent text, and child text.

#Reformat parent and child tiernames into vectors.
parent_tiernames <- (str_split(parent_tiernames,","))[[1]]
if (child_tiernames=="") child_tiernames = NA else child_tiernames = (str_split(child_tiernames,","))[[1]]

#Create table as list.
parent_table_list <- as.list(parent_tiernames)
for (i in 1:length(parent_table_list)) (
  if (!is.na(child_tiernames[i])) (
  parent_table_list[[i]] <- data.frame(parent_child_times_text(parent_tiernames[i],child_tiernames[i]), stringsAsFactors = FALSE)
  )
  else
  parent_table_list[[i]] <- data.frame(parent_times_text(parent_tiernames[i]), stringsAsFactors = FALSE)
  )

#Convert to table.
parent_table <- bind_rows(parent_table_list) %>%
  arrange(StartTime)

#Convert non-text content to SRT format
parent_table <- parent_table %>%
  mutate(SRTTime = paste(gsub("\\.",",",StartTime_SRT)," --> ",gsub("\\.",",",EndTime_SRT),sep="")) %>%
  #Concatenate text 
  mutate(SRTText=ifelse(is.na(child_text),paste(parent_text),paste(parent_text,child_text,sep="\n")))

#Remove lines with no content.
parent_table <- parent_table %>%
  filter(!SRTText=="") %>%
#Add row numbers.
  mutate(SubtitleNumber=seq(1:nrow(parent_table)))

#Concatenate rownumber, time, and text
parent_table <- parent_table %>%
  mutate(SRT=paste(SubtitleNumber,SRTTime,SRTText,"",sep="\n"))

#Write to file.

text <- paste(parent_table$SRT,sep="\n")

writeLines(text,output_file)